﻿Console.WriteLine("Введите число:");
int num = Convert.ToInt32(Console.ReadLine());
 if (num % 2 == 1)
 {
   Console.WriteLine("Число " + num + " является нечетным");
 }
else;

if (num % 2 == 0)
{
   Console.WriteLine("Число " + num + " является четным");
}
else;
