﻿Console.WriteLine ("Введите число: ");
int num = Convert.ToInt32(Console.ReadLine());
Console.WriteLine("Чётные числа от 1 до " + num);
int CH = 1;
while (CH <= num)
 {
  if (CH % 2 != 1)
 {
   Console.Write(CH + ", ");
 }
 else;
CH++;
}


